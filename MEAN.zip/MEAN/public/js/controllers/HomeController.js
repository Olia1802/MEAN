angular.module('HomeController', [])
  .controller('HomeController', function($scope) {
    $scope.message = 'Welcome to tutorials point angular app!';
  });
