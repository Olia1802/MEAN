angular.module('sampleApp', ['ngRoute', 'appRoutes', 'HomeController', 'StudentController']);
