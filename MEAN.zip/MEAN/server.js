const express = require('express');
const mongoose = require('mongoose');
const config = require('./config/db');  
const Student = require('./app/models/students');  
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

 
mongoose.connect(config.url)
    .then(() => console.log('MongoDB connection created'))
    .catch(err => console.log('MongoDB connection error:', err));

 
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());

 
app.get('/', (req, res) => {
    res.send('Welcome to Tutorialspoint!');
});

app.get('/route', (req, res) => {
    res.send('This is routing for the application developed using Node and Express...');
});

app.get('/api/students', (req, res) => {
    Student.find({})
        .then(students => res.json(students))
        .catch(err => res.status(500).send(err));
});


app.post('/api/students/add', (req, res) => {
    const student = new Student({
        name: req.body.name
    });

    student.save()
        .then(() => res.json({ message: 'Student created!' }))
        .catch(err => res.status(500).send(err));
});

app.delete('/api/students/:id', (req, res) => {
    Student.deleteOne({ _id: req.params.id })
        .then(() => res.json({ message: 'Successfully deleted' }))
        .catch(err => res.status(500).send(err));
});

const path = require('path');

// Налаштування статичної папки
app.use(express.static(path.join(__dirname, 'public')));

// Повертаємо index.html для Angular маршрутів
app.get('*', (req, res) => {
res.sendFile(path.join(__dirname, 'public/index.html'));
});

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
});
